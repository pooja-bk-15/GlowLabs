const EMAIL_INVALID = "EMAIL_INVALID";

const ACTION_EMAIL_INVALID = () => {
  return {
    type: EMAIL_INVALID
  };
};

export default ACTION_EMAIL_INVALID;
