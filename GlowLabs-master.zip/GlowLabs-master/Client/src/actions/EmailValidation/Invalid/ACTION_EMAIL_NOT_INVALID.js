const EMAIL_NOT_INVALID = "EMAIL_NOT_INVALID";

const ACTION_EMAIL_NOT_INVALID = () => {
  return {
    type: EMAIL_NOT_INVALID
  };
};

export default ACTION_EMAIL_NOT_INVALID;
