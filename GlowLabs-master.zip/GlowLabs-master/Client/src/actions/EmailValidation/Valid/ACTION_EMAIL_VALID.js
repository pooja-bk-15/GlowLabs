const EMAIL_VALID = "EMAIL_VALID";

const ACTION_EMAIL_VALID = () => {
  return {
    type: EMAIL_VALID
  };
};

export default ACTION_EMAIL_VALID;
