const EMAIL_NOT_VALID = "EMAIL_NOT_VALID";

const ACTION_EMAIL_NOT_VALID = () => {
  return {
    type: EMAIL_NOT_VALID
  };
};

export default ACTION_EMAIL_NOT_VALID;
