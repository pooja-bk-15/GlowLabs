const BODY_SCROLL_ALLOW = "BODY_SCROLL_ALLOW";

const ACTION_BODY_SCROLL_ALLOW = () => {
  return {
    type: BODY_SCROLL_ALLOW
  };
};

export default ACTION_BODY_SCROLL_ALLOW;
