const BODY_SCROLL_RESET = "BODY_SCROLL_RESET";

const ACTION_BODY_SCROLL_RESET = () => {
  return {
    type: BODY_SCROLL_RESET
  };
};

export default ACTION_BODY_SCROLL_RESET;
