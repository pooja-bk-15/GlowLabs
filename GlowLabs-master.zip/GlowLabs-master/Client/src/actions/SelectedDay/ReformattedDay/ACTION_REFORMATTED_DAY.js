const REFORMATTED_DAY = "REFORMATTED_DAY";

const ACTION_REFORMATTED_DAY = day => {
  return {
    type: REFORMATTED_DAY,
    day
  };
};

export default ACTION_REFORMATTED_DAY;
