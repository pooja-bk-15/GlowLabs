const DAY_OF_THE_WEEK_RESET = "DAY_OF_THE_WEEK_RESET";

const ACTION_DAY_OF_THE_WEEK_RESET = () => {
  return {
    type: DAY_OF_THE_WEEK_RESET
  };
};

export default ACTION_DAY_OF_THE_WEEK_RESET;
