const USER_SCROLLED = "USER_SCROLLED";

const ACTION_USER_SCROLLED = () => {
  return {
    type: USER_SCROLLED
  };
};

export default ACTION_USER_SCROLLED;
