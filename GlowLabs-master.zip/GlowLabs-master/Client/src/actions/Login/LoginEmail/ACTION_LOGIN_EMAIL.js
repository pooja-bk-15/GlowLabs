const LOGIN_EMAIL = "LOGIN_EMAIL";

const ACTION_LOGIN_EMAIL = login_email => {
  return {
    type: LOGIN_EMAIL,
    login_email
  };
};

export default ACTION_LOGIN_EMAIL;
