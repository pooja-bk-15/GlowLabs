const LOGIN_EMAIL_RESET = "LOGIN_EMAIL_RESET";

const ACTION_LOGIN_EMAIL_RESET = () => {
  return {
    type: LOGIN_EMAIL_RESET
  };
};

export default ACTION_LOGIN_EMAIL_RESET;
