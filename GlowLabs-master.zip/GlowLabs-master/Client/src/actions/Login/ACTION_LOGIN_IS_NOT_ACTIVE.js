const LOGIN_IS_NOT_ACTIVE = "LOGIN_IS_NOT_ACTIVE";

const ACTION_LOGIN_IS_NOT_ACTIVE = () => {
  return {
    type: LOGIN_IS_NOT_ACTIVE
  };
};

export default ACTION_LOGIN_IS_NOT_ACTIVE;
