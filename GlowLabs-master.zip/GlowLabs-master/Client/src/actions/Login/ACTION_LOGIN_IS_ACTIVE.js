const LOGIN_IS_ACTIVE = "LOGIN_IS_ACTIVE";

const ACTION_LOGIN_IS_ACTIVE = () => {
  return {
    type: LOGIN_IS_ACTIVE
  };
};

export default ACTION_LOGIN_IS_ACTIVE;
