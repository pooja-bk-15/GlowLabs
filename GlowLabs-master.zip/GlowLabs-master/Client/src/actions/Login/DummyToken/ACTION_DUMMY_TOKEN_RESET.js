const DUMMY_TOKEN_RESET = "DUMMY_TOKEN_RESET";

const ACTION_DUMMY_TOKEN_RESET = () => {
  return {
    type: DUMMY_TOKEN_RESET
  };
};

export default ACTION_DUMMY_TOKEN_RESET;
