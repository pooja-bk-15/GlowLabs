const LOGIN_PASSWORD = "LOGIN_PASSWORD";

const ACTION_LOGIN_PASSWORD = login_password => {
  return {
    type: LOGIN_PASSWORD,
    login_password
  };
};

export default ACTION_LOGIN_PASSWORD;
