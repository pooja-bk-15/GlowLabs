const OIL_PRODUCT_NAME = "OIL_PRODUCT_NAME";

const ACTION_OIL_PRODUCT_NAME = (oil_product_name) => {
  return {
    type: OIL_PRODUCT_NAME,
    oil_product_name,
  };
};

export default ACTION_OIL_PRODUCT_NAME;
