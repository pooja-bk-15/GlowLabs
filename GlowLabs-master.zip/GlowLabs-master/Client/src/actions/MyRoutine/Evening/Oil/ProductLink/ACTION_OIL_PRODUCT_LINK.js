const OIL_PRODUCT_LINK = "OIL_PRODUCT_LINK";

const ACTION_OIL_PRODUCT_LINK = (oil_product_link) => {
  return {
    type: OIL_PRODUCT_LINK,
    oil_product_link,
  };
};

export default ACTION_OIL_PRODUCT_LINK;
