const RESET_ALL_OIL_FIELDS = "RESET_ALL_OIL_FIELDS";

const ACTION_RESET_ALL_OIL_FIELDS = () => {
  return {
    type: RESET_ALL_OIL_FIELDS,
  };
};

export default ACTION_RESET_ALL_OIL_FIELDS;
