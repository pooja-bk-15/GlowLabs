const OIL_PRODUCT_USE_NOTES = "OIL_PRODUCT_USE_NOTES";

const ACTION_OIL_PRODUCT_USE_NOTES = (oil_product_use_notes) => {
  return {
    type: OIL_PRODUCT_USE_NOTES,
    oil_product_use_notes,
  };
};

export default ACTION_OIL_PRODUCT_USE_NOTES;
