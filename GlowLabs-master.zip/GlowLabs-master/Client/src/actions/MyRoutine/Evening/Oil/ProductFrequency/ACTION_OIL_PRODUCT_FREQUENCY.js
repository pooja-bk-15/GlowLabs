const OIL_PRODUCT_FREQUENCY = "OIL_PRODUCT_FREQUENCY";

const ACTION_OIL_PRODUCT_FREQUENCY = (oil_product_frequency) => {
  return {
    type: OIL_PRODUCT_FREQUENCY,
    oil_product_frequency,
  };
};

export default ACTION_OIL_PRODUCT_FREQUENCY;
