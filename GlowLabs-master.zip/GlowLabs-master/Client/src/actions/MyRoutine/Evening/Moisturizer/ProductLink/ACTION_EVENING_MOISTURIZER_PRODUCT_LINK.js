const EVENING_MOISTURIZER_PRODUCT_LINK = "EVENING_MOISTURIZER_PRODUCT_LINK";

const ACTION_EVENING_MOISTURIZER_PRODUCT_LINK = (
  evening_moisturizer_product_link
) => {
  return {
    type: EVENING_MOISTURIZER_PRODUCT_LINK,
    evening_moisturizer_product_link,
  };
};

export default ACTION_EVENING_MOISTURIZER_PRODUCT_LINK;
