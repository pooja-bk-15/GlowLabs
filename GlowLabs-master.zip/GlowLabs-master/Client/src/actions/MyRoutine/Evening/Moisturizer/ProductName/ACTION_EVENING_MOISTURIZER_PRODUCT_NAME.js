const EVENING_MOISTURIZER_PRODUCT_NAME = "EVENING_MOISTURIZER_PRODUCT_NAME";

const ACTION_EVENING_MOISTURIZER_PRODUCT_NAME = (
  evening_moisturizer_product_name
) => {
  return {
    type: EVENING_MOISTURIZER_PRODUCT_NAME,
    evening_moisturizer_product_name,
  };
};

export default ACTION_EVENING_MOISTURIZER_PRODUCT_NAME;
