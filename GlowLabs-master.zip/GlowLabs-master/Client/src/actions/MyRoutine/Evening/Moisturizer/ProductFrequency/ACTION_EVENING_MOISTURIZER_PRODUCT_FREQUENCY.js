const EVENING_MOISTURIZER_PRODUCT_FREQUENCY =
  "EVENING_MOISTURIZER_PRODUCT_FREQUENCY";

const ACTION_EVENING_MOISTURIZER_PRODUCT_FREQUENCY = (
  evening_moisturizer_product_frequency
) => {
  return {
    type: EVENING_MOISTURIZER_PRODUCT_FREQUENCY,
    evening_moisturizer_product_frequency,
  };
};

export default ACTION_EVENING_MOISTURIZER_PRODUCT_FREQUENCY;
