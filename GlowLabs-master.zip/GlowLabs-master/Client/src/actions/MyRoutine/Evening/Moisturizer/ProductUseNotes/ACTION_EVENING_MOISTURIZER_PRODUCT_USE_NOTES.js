const EVENING_MOISTURIZER_PRODUCT_USE_NOTES =
  "EVENING_MOISTURIZER_PRODUCT_USE_NOTES";

const ACTION_EVENING_MOISTURIZER_PRODUCT_USE_NOTES = (
  evening_moisturizer_product_use_notes
) => {
  return {
    type: EVENING_MOISTURIZER_PRODUCT_USE_NOTES,
    evening_moisturizer_product_use_notes,
  };
};

export default ACTION_EVENING_MOISTURIZER_PRODUCT_USE_NOTES;
