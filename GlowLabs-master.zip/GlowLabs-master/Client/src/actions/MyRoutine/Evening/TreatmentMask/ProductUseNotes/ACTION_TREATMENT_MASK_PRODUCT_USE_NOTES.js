const TREATMENT_MASK_PRODUCT_USE_NOTES = "TREATMENT_MASK_PRODUCT_USE_NOTES";

const ACTION_TREATMENT_MASK_PRODUCT_USE_NOTES = (
  treatment_mask_product_use_notes
) => {
  return {
    type: TREATMENT_MASK_PRODUCT_USE_NOTES,
    treatment_mask_product_use_notes,
  };
};

export default ACTION_TREATMENT_MASK_PRODUCT_USE_NOTES;
