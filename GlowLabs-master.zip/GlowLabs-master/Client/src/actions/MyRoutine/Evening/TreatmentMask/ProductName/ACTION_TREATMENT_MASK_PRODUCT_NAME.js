const TREATMENT_MASK_PRODUCT_NAME = "TREATMENT_MASK_PRODUCT_NAME";

const ACTION_TREATMENT_MASK_PRODUCT_NAME = (treatment_mask_product_name) => {
  return {
    type: TREATMENT_MASK_PRODUCT_NAME,
    treatment_mask_product_name,
  };
};

export default ACTION_TREATMENT_MASK_PRODUCT_NAME;
