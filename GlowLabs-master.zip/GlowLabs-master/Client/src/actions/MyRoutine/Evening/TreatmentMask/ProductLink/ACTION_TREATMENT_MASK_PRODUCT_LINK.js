const TREATMENT_MASK_PRODUCT_LINK = "TREATMENT_MASK_PRODUCT_LINK";

const ACTION_TREATMENT_MASK_PRODUCT_LINK = (treatment_mask_product_link) => {
  return {
    type: TREATMENT_MASK_PRODUCT_LINK,
    treatment_mask_product_link,
  };
};

export default ACTION_TREATMENT_MASK_PRODUCT_LINK;
