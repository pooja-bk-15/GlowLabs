const TREATMENT_MASK_PRODUCT_FREQUENCY = "TREATMENT_MASK_PRODUCT_FREQUENCY";

const ACTION_TREATMENT_MASK_PRODUCT_FREQUENCY = (
  treatment_mask_product_frequency
) => {
  return {
    type: TREATMENT_MASK_PRODUCT_FREQUENCY,
    treatment_mask_product_frequency,
  };
};

export default ACTION_TREATMENT_MASK_PRODUCT_FREQUENCY;
