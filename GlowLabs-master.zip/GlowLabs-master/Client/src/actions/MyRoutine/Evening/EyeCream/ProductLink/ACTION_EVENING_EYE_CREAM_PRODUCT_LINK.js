const EVENING_EYE_CREAM_PRODUCT_LINK = "EVENING_EYE_CREAM_PRODUCT_LINK";

const ACTION_EVENING_EYE_CREAM_PRODUCT_LINK = (
  evening_eye_cream_product_link
) => {
  return {
    type: EVENING_EYE_CREAM_PRODUCT_LINK,
    evening_eye_cream_product_link,
  };
};

export default ACTION_EVENING_EYE_CREAM_PRODUCT_LINK;
