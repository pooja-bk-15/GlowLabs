const EVENING_EYE_CREAM_PRODUCT_NAME = "EVENING_EYE_CREAM_PRODUCT_NAME";

const ACTION_EVENING_EYE_CREAM_PRODUCT_NAME = (
  evening_eye_cream_product_name
) => {
  return {
    type: EVENING_EYE_CREAM_PRODUCT_NAME,
    evening_eye_cream_product_name,
  };
};

export default ACTION_EVENING_EYE_CREAM_PRODUCT_NAME;
