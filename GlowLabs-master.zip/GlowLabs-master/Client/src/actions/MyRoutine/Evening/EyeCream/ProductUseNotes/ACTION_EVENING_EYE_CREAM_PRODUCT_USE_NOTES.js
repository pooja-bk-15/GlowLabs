const EVENING_EYE_CREAM_PRODUCT_USE_NOTES =
  "EVENING_EYE_CREAM_PRODUCT_USE_NOTES";

const ACTION_EVENING_EYE_CREAM_PRODUCT_USE_NOTES = (
  evening_eye_cream_product_use_notes
) => {
  return {
    type: EVENING_EYE_CREAM_PRODUCT_USE_NOTES,
    evening_eye_cream_product_use_notes,
  };
};

export default ACTION_EVENING_EYE_CREAM_PRODUCT_USE_NOTES;
