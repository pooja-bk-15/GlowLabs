const EVENING_EYE_CREAM_PRODUCT_FREQUENCY =
  "EVENING_EYE_CREAM_PRODUCT_FREQUENCY";

const ACTION_EVENING_EYE_CREAM_PRODUCT_FREQUENCY = (
  evening_eye_cream_product_frequency
) => {
  return {
    type: EVENING_EYE_CREAM_PRODUCT_FREQUENCY,
    evening_eye_cream_product_frequency,
  };
};

export default ACTION_EVENING_EYE_CREAM_PRODUCT_FREQUENCY;
