const NIGHT_MASK_PRODUCT_NAME = "NIGHT_MASK_PRODUCT_NAME";

const ACTION_NIGHT_MASK_PRODUCT_NAME = (night_mask_product_name) => {
  return {
    type: NIGHT_MASK_PRODUCT_NAME,
    night_mask_product_name,
  };
};

export default ACTION_NIGHT_MASK_PRODUCT_NAME;
