const NIGHT_MASK_PRODUCT_USE_NOTES = "NIGHT_MASK_PRODUCT_USE_NOTES";

const ACTION_NIGHT_MASK_PRODUCT_USE_NOTES = (night_mask_product_use_notes) => {
  return {
    type: NIGHT_MASK_PRODUCT_USE_NOTES,
    night_mask_product_use_notes,
  };
};

export default ACTION_NIGHT_MASK_PRODUCT_USE_NOTES;
