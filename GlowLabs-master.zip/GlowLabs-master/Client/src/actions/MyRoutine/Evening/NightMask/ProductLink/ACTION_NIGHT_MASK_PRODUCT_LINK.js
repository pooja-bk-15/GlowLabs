const NIGHT_MASK_PRODUCT_LINK = "NIGHT_MASK_PRODUCT_LINK";

const ACTION_NIGHT_MASK_PRODUCT_LINK = (night_mask_product_link) => {
  return {
    type: NIGHT_MASK_PRODUCT_LINK,
    night_mask_product_link,
  };
};

export default ACTION_NIGHT_MASK_PRODUCT_LINK;
