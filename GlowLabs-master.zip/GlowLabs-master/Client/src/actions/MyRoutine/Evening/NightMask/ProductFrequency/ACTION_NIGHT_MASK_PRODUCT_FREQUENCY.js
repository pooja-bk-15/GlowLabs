const NIGHT_MASK_PRODUCT_FREQUENCY = "NIGHT_MASK_PRODUCT_FREQUENCY";

const ACTION_NIGHT_MASK_PRODUCT_FREQUENCY = (night_mask_product_frequency) => {
  return {
    type: NIGHT_MASK_PRODUCT_FREQUENCY,
    night_mask_product_frequency,
  };
};

export default ACTION_NIGHT_MASK_PRODUCT_FREQUENCY;
