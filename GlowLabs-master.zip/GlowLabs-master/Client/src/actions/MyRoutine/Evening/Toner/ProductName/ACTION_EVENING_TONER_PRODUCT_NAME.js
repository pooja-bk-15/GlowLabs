const EVENING_TONER_PRODUCT_NAME = "EVENING_TONER_PRODUCT_NAME";

const ACTION_EVENING_TONER_PRODUCT_NAME = (evening_toner_product_name) => {
  return {
    type: EVENING_TONER_PRODUCT_NAME,
    evening_toner_product_name,
  };
};

export default ACTION_EVENING_TONER_PRODUCT_NAME;
