const EVENING_TONER_PRODUCT_USE_NOTES = "EVENING_TONER_PRODUCT_USE_NOTES";

const ACTION_EVENING_TONER_PRODUCT_USE_NOTES = (
  evening_toner_product_use_notes
) => {
  return {
    type: EVENING_TONER_PRODUCT_USE_NOTES,
    evening_toner_product_use_notes,
  };
};

export default ACTION_EVENING_TONER_PRODUCT_USE_NOTES;
