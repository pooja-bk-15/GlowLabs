const EVENING_TONER_PRODUCT_FREQUENCY = "EVENING_TONER_PRODUCT_FREQUENCY";

const ACTION_EVENING_TONER_PRODUCT_FREQUENCY = (
  evening_toner_product_frequency
) => {
  return {
    type: EVENING_TONER_PRODUCT_FREQUENCY,
    evening_toner_product_frequency,
  };
};

export default ACTION_EVENING_TONER_PRODUCT_FREQUENCY;
