const EVENING_TONER_PRODUCT_LINK = "EVENING_TONER_PRODUCT_LINK";

const ACTION_EVENING_TONER_PRODUCT_LINK = (evening_toner_product_link) => {
  return {
    type: EVENING_TONER_PRODUCT_LINK,
    evening_toner_product_link,
  };
};

export default ACTION_EVENING_TONER_PRODUCT_LINK;
