const EXFOLIATOR_PRODUCT_NAME = "EXFOLIATOR_PRODUCT_NAME";

const ACTION_EXFOLIATOR_PRODUCT_NAME = (exfoliator_product_name) => {
  return {
    type: EXFOLIATOR_PRODUCT_NAME,
    exfoliator_product_name,
  };
};

export default ACTION_EXFOLIATOR_PRODUCT_NAME;
