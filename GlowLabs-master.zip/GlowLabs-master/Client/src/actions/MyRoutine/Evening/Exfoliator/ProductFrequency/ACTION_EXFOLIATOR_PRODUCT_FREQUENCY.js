const EXFOLIATOR_PRODUCT_FREQUENCY = "EXFOLIATOR_PRODUCT_FREQUENCY";

const ACTION_EXFOLIATOR_PRODUCT_FREQUENCY = (exfoliator_product_frequency) => {
  return {
    type: EXFOLIATOR_PRODUCT_FREQUENCY,
    exfoliator_product_frequency,
  };
};

export default ACTION_EXFOLIATOR_PRODUCT_FREQUENCY;
