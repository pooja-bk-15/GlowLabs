const EXFOLIATOR_PRODUCT_LINK = "EXFOLIATOR_PRODUCT_LINK";

const ACTION_EXFOLIATOR_PRODUCT_LINK = (exfoliator_product_link) => {
  return {
    type: EXFOLIATOR_PRODUCT_LINK,
    exfoliator_product_link,
  };
};

export default ACTION_EXFOLIATOR_PRODUCT_LINK;
