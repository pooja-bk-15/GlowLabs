const EXFOLIATOR_PRODUCT_USE_NOTES = "EXFOLIATOR_PRODUCT_USE_NOTES";

const ACTION_EXFOLIATOR_PRODUCT_USE_NOTES = (exfoliator_product_use_notes) => {
  return {
    type: EXFOLIATOR_PRODUCT_USE_NOTES,
    exfoliator_product_use_notes,
  };
};

export default ACTION_EXFOLIATOR_PRODUCT_USE_NOTES;
