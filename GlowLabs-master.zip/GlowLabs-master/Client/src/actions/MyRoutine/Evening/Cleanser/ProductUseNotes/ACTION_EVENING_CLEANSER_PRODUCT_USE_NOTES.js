const EVENING_CLEANSER_PRODUCT_USE_NOTES = "EVENING_CLEANSER_PRODUCT_USE_NOTES";

const ACTION_EVENING_CLEANSER_PRODUCT_USE_NOTES = (
  evening_cleanser_product_use_notes
) => {
  return {
    type: EVENING_CLEANSER_PRODUCT_USE_NOTES,
    evening_cleanser_product_use_notes,
  };
};

export default ACTION_EVENING_CLEANSER_PRODUCT_USE_NOTES;
