const EVENING_CLEANSER_PRODUCT_FREQUENCY = "EVENING_CLEANSER_PRODUCT_FREQUENCY";

const ACTION_EVENING_CLEANSER_PRODUCT_FREQUENCY = (
  evening_cleanser_product_frequency
) => {
  return {
    type: EVENING_CLEANSER_PRODUCT_FREQUENCY,
    evening_cleanser_product_frequency,
  };
};

export default ACTION_EVENING_CLEANSER_PRODUCT_FREQUENCY;
