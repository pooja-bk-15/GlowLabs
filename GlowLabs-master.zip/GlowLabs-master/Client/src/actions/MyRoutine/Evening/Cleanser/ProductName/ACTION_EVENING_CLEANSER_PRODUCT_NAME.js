const EVENING_CLEANSER_PRODUCT_NAME = "EVENING_CLEANSER_PRODUCT_NAME";

const ACTION_EVENING_CLEANSER_PRODUCT_NAME = (
  evening_cleanser_product_name
) => {
  return {
    type: EVENING_CLEANSER_PRODUCT_NAME,
    evening_cleanser_product_name,
  };
};

export default ACTION_EVENING_CLEANSER_PRODUCT_NAME;
