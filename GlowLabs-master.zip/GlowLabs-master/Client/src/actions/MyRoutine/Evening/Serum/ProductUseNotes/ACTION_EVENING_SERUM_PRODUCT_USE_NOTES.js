const EVENING_SERUM_PRODUCT_USE_NOTES = "EVENING_SERUM_PRODUCT_USE_NOTES";

const ACTION_EVENING_SERUM_PRODUCT_USE_NOTES = (
  evening_serum_product_use_notes
) => {
  return {
    type: EVENING_SERUM_PRODUCT_USE_NOTES,
    evening_serum_product_use_notes,
  };
};

export default ACTION_EVENING_SERUM_PRODUCT_USE_NOTES;
