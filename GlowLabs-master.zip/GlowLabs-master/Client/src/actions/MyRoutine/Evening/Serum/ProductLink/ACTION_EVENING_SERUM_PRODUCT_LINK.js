const EVENING_SERUM_PRODUCT_LINK = "EVENING_SERUM_PRODUCT_LINK";

const ACTION_EVENING_SERUM_PRODUCT_LINK = (evening_serum_product_link) => {
  return {
    type: EVENING_SERUM_PRODUCT_LINK,
    evening_serum_product_link,
  };
};

export default ACTION_EVENING_SERUM_PRODUCT_LINK;
