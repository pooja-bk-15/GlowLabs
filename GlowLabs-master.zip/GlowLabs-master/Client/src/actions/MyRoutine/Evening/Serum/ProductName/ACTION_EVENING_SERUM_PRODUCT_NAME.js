const EVENING_SERUM_PRODUCT_NAME = "EVENING_SERUM_PRODUCT_NAME";

const ACTION_EVENING_SERUM_PRODUCT_NAME = (evening_serum_product_name) => {
  return {
    type: EVENING_SERUM_PRODUCT_NAME,
    evening_serum_product_name,
  };
};

export default ACTION_EVENING_SERUM_PRODUCT_NAME;
