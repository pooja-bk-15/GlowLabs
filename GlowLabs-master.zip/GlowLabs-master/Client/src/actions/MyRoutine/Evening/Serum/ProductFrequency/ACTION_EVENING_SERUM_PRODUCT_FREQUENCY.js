const EVENING_SERUM_PRODUCT_FREQUENCY = "EVENING_SERUM_PRODUCT_FREQUENCY";

const ACTION_EVENING_SERUM_PRODUCT_FREQUENCY = (
  evening_serum_product_frequency
) => {
  return {
    type: EVENING_SERUM_PRODUCT_FREQUENCY,
    evening_serum_product_frequency,
  };
};

export default ACTION_EVENING_SERUM_PRODUCT_FREQUENCY;
