const SPOT_TREATMENT_PRODUCT_USE_NOTES = "SPOT_TREATMENT_PRODUCT_USE_NOTES";

const ACTION_SPOT_TREATMENT_PRODUCT_USE_NOTES = (
  spot_treatment_product_use_notes
) => {
  return {
    type: SPOT_TREATMENT_PRODUCT_USE_NOTES,
    spot_treatment_product_use_notes,
  };
};

export default ACTION_SPOT_TREATMENT_PRODUCT_USE_NOTES;
