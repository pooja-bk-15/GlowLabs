const SPOT_TREATMENT_PRODUCT_FREQUENCY = "SPOT_TREATMENT_PRODUCT_FREQUENCY";

const ACTION_SPOT_TREATMENT_PRODUCT_FREQUENCY = (
  spot_treatment_product_frequency
) => {
  return {
    type: SPOT_TREATMENT_PRODUCT_FREQUENCY,
    spot_treatment_product_frequency,
  };
};

export default ACTION_SPOT_TREATMENT_PRODUCT_FREQUENCY;
