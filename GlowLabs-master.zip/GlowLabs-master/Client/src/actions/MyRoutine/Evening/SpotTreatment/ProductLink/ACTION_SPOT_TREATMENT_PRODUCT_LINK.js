const SPOT_TREATMENT_PRODUCT_LINK = "SPOT_TREATMENT_PRODUCT_LINK";

const ACTION_SPOT_TREATMENT_PRODUCT_LINK = (spot_treatment_product_link) => {
  return {
    type: SPOT_TREATMENT_PRODUCT_LINK,
    spot_treatment_product_link,
  };
};

export default ACTION_SPOT_TREATMENT_PRODUCT_LINK;
