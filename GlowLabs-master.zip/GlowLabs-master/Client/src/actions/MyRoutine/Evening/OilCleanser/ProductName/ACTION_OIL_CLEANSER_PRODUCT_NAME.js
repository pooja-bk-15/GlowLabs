const OIL_CLEANSER_PRODUCT_NAME = "OIL_CLEANSER_PRODUCT_NAME";

const ACTION_OIL_CLEANSER_PRODUCT_NAME = (oil_cleanser_product_name) => {
  return {
    type: OIL_CLEANSER_PRODUCT_NAME,
    oil_cleanser_product_name,
  };
};

export default ACTION_OIL_CLEANSER_PRODUCT_NAME;
