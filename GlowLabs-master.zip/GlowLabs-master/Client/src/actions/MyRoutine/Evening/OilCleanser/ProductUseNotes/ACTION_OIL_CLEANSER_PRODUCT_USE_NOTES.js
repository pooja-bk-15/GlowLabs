const OIL_CLEANSER_PRODUCT_USE_NOTES = "OIL_CLEANSER_PRODUCT_USE_NOTES";

const ACTION_OIL_CLEANSER_PRODUCT_USE_NOTES = (
  oil_cleanser_product_use_notes
) => {
  return {
    type: OIL_CLEANSER_PRODUCT_USE_NOTES,
    oil_cleanser_product_use_notes,
  };
};

export default ACTION_OIL_CLEANSER_PRODUCT_USE_NOTES;
