const OIL_CLEANSER_PRODUCT_FREQUENCY = "OIL_CLEANSER_PRODUCT_FREQUENCY";

const ACTION_OIL_CLEANSER_PRODUCT_FREQUENCY = (
  oil_cleanser_product_frequency
) => {
  return {
    type: OIL_CLEANSER_PRODUCT_FREQUENCY,
    oil_cleanser_product_frequency,
  };
};

export default ACTION_OIL_CLEANSER_PRODUCT_FREQUENCY;
