const OIL_CLEANSER_PRODUCT_LINK = "OIL_CLEANSER_PRODUCT_LINK";

const ACTION_OIL_CLEANSER_PRODUCT_LINK = (oil_cleanser_product_link) => {
  return {
    type: OIL_CLEANSER_PRODUCT_LINK,
    oil_cleanser_product_link,
  };
};

export default ACTION_OIL_CLEANSER_PRODUCT_LINK;
