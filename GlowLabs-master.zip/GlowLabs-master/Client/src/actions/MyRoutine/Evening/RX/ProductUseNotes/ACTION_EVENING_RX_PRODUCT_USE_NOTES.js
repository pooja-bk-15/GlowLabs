const EVENING_RX_PRODUCT_USE_NOTES = "EVENING_RX_PRODUCT_USE_NOTES";

const ACTION_EVENING_RX_PRODUCT_USE_NOTES = (evening_rx_product_use_notes) => {
  return {
    type: EVENING_RX_PRODUCT_USE_NOTES,
    evening_rx_product_use_notes,
  };
};

export default ACTION_EVENING_RX_PRODUCT_USE_NOTES;
