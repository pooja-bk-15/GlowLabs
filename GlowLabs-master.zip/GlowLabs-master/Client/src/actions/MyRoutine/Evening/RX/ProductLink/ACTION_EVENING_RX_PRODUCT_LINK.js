const EVENING_RX_PRODUCT_LINK = "EVENING_RX_PRODUCT_LINK";

const ACTION_EVENING_RX_PRODUCT_LINK = (evening_rx_product_link) => {
  return {
    type: EVENING_RX_PRODUCT_LINK,
    evening_rx_product_link,
  };
};

export default ACTION_EVENING_RX_PRODUCT_LINK;
