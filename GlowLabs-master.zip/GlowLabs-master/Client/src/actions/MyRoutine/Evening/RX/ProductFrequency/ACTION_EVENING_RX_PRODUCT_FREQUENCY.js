const EVENING_RX_PRODUCT_FREQUENCY = "EVENING_RX_PRODUCT_FREQUENCY";

const ACTION_EVENING_RX_PRODUCT_FREQUENCY = (evening_rx_product_frequency) => {
  return {
    type: EVENING_RX_PRODUCT_FREQUENCY,
    evening_rx_product_frequency,
  };
};

export default ACTION_EVENING_RX_PRODUCT_FREQUENCY;
