const EVENING_RX_PRODUCT_NAME = "EVENING_RX_PRODUCT_NAME";

const ACTION_EVENING_RX_PRODUCT_NAME = (evening_rx_product_name) => {
  return {
    type: EVENING_RX_PRODUCT_NAME,
    evening_rx_product_name,
  };
};

export default ACTION_EVENING_RX_PRODUCT_NAME;
