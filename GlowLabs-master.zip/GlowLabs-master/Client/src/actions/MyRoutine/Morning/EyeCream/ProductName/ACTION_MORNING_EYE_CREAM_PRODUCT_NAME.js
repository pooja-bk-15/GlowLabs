const MORNING_EYE_CREAM_PRODUCT_NAME = "MORNING_EYE_CREAM_PRODUCT_NAME";

const ACTION_MORNING_EYE_CREAM_PRODUCT_NAME = (
  morning_eye_cream_product_name
) => {
  return {
    type: MORNING_EYE_CREAM_PRODUCT_NAME,
    morning_eye_cream_product_name,
  };
};

export default ACTION_MORNING_EYE_CREAM_PRODUCT_NAME;
