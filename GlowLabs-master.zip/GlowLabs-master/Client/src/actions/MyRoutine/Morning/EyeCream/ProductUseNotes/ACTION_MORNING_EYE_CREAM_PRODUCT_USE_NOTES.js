const MORNING_EYE_CREAM_PRODUCT_USE_NOTES =
  "MORNING_EYE_CREAM_PRODUCT_USE_NOTES";

const ACTION_MORNING_EYE_CREAM_PRODUCT_USE_NOTES = (
  morning_eye_cream_product_use_notes
) => {
  return {
    type: MORNING_EYE_CREAM_PRODUCT_USE_NOTES,
    morning_eye_cream_product_use_notes,
  };
};

export default ACTION_MORNING_EYE_CREAM_PRODUCT_USE_NOTES;
