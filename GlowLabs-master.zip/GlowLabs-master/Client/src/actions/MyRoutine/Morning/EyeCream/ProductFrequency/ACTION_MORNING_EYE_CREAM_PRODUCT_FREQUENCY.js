const MORNING_EYE_CREAM_PRODUCT_FREQUENCY =
  "MORNING_EYE_CREAM_PRODUCT_FREQUENCY";

const ACTION_MORNING_EYE_CREAM_PRODUCT_FREQUENCY = (
  morning_eye_cream_product_frequency
) => {
  return {
    type: MORNING_EYE_CREAM_PRODUCT_FREQUENCY,
    morning_eye_cream_product_frequency,
  };
};

export default ACTION_MORNING_EYE_CREAM_PRODUCT_FREQUENCY;
