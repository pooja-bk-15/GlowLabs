const MORNING_EYE_CREAM_PRODUCT_LINK = "MORNING_EYE_CREAM_PRODUCT_LINK";

const ACTION_MORNING_EYE_CREAM_PRODUCT_LINK = (
  morning_eye_cream_product_link
) => {
  return {
    type: MORNING_EYE_CREAM_PRODUCT_LINK,
    morning_eye_cream_product_link,
  };
};

export default ACTION_MORNING_EYE_CREAM_PRODUCT_LINK;
