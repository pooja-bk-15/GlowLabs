const MORNING_TONER_PRODUCT_FREQUENCY = "MORNING_TONER_PRODUCT_FREQUENCY";

const ACTION_MORNING_TONER_PRODUCT_FREQUENCY = (
  morning_toner_product_frequency
) => {
  return {
    type: MORNING_TONER_PRODUCT_FREQUENCY,
    morning_toner_product_frequency,
  };
};

export default ACTION_MORNING_TONER_PRODUCT_FREQUENCY;
