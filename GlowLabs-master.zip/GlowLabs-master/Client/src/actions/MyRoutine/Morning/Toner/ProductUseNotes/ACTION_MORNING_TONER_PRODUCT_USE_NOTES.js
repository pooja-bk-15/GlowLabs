const MORNING_TONER_PRODUCT_USE_NOTES = "MORNING_TONER_PRODUCT_USE_NOTES";

const ACTION_MORNING_TONER_PRODUCT_USE_NOTES = (
  morning_toner_product_use_notes
) => {
  return {
    type: MORNING_TONER_PRODUCT_USE_NOTES,
    morning_toner_product_use_notes,
  };
};

export default ACTION_MORNING_TONER_PRODUCT_USE_NOTES;
