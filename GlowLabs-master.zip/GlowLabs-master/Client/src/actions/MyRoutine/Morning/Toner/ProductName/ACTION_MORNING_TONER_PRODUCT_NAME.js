const MORNING_TONER_PRODUCT_NAME = "MORNING_TONER_PRODUCT_NAME";

const ACTION_MORNING_TONER_PRODUCT_NAME = (morning_toner_product_name) => {
  return {
    type: MORNING_TONER_PRODUCT_NAME,
    morning_toner_product_name,
  };
};

export default ACTION_MORNING_TONER_PRODUCT_NAME;
