const MORNING_TONER_PRODUCT_LINK = "MORNING_TONER_PRODUCT_LINK";

const ACTION_MORNING_TONER_PRODUCT_LINK = (morning_toner_product_link) => {
  return {
    type: MORNING_TONER_PRODUCT_LINK,
    morning_toner_product_link,
  };
};

export default ACTION_MORNING_TONER_PRODUCT_LINK;
