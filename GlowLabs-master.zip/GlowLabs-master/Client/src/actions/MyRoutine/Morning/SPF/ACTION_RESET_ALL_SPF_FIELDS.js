const RESET_ALL_SPF_FIELDS = "RESET_ALL_SPF_FIELDS";

const ACTION_RESET_ALL_SPF_FIELDS = () => {
  return {
    type: RESET_ALL_SPF_FIELDS,
  };
};

export default ACTION_RESET_ALL_SPF_FIELDS;
