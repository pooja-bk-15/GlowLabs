const SPF_PRODUCT_LINK = "SPF_PRODUCT_LINK";

const ACTION_SPF_PRODUCT_LINK = (spf_product_link) => {
  return {
    type: SPF_PRODUCT_LINK,
    spf_product_link,
  };
};

export default ACTION_SPF_PRODUCT_LINK;
