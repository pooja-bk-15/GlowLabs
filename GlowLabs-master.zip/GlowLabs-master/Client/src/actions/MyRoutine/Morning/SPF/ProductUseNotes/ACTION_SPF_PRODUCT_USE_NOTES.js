const SPF_PRODUCT_USE_NOTES = "SPF_PRODUCT_USE_NOTES";

const ACTION_SPF_PRODUCT_USE_NOTES = (spf_product_use_notes) => {
  return {
    type: SPF_PRODUCT_USE_NOTES,
    spf_product_use_notes,
  };
};

export default ACTION_SPF_PRODUCT_USE_NOTES;
