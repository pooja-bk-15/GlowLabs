const MORNING_MOISTURIZER_PRODUCT_USE_NOTES =
  "MORNING_MOISTURIZER_PRODUCT_USE_NOTES";

const ACTION_MORNING_MOISTURIZER_PRODUCT_USE_NOTES = (
  morning_moisturizer_product_use_notes
) => {
  return {
    type: MORNING_MOISTURIZER_PRODUCT_USE_NOTES,
    morning_moisturizer_product_use_notes,
  };
};

export default ACTION_MORNING_MOISTURIZER_PRODUCT_USE_NOTES;
