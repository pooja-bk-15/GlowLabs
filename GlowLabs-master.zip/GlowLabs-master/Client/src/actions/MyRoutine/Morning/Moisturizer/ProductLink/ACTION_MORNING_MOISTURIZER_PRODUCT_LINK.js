const MORNING_MOISTURIZER_PRODUCT_LINK = "MORNING_MOISTURIZER_PRODUCT_LINK";

const ACTION_MORNING_MOISTURIZER_PRODUCT_LINK = (
  morning_moisturizer_product_link
) => {
  return {
    type: MORNING_MOISTURIZER_PRODUCT_LINK,
    morning_moisturizer_product_link,
  };
};

export default ACTION_MORNING_MOISTURIZER_PRODUCT_LINK;
