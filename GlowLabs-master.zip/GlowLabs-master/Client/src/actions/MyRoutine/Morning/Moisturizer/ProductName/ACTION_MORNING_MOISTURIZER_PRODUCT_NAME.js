const MORNING_MOISTURIZER_PRODUCT_NAME = "MORNING_MOISTURIZER_PRODUCT_NAME";

const ACTION_MORNING_MOISTURIZER_PRODUCT_NAME = (
  morning_moisturizer_product_name
) => {
  return {
    type: MORNING_MOISTURIZER_PRODUCT_NAME,
    morning_moisturizer_product_name,
  };
};

export default ACTION_MORNING_MOISTURIZER_PRODUCT_NAME;
