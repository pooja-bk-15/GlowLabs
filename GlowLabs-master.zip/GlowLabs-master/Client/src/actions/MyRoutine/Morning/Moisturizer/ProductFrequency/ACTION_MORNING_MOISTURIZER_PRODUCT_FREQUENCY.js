const MORNING_MOISTURIZER_PRODUCT_FREQUENCY =
  "MORNING_MOISTURIZER_PRODUCT_FREQUENCY";

const ACTION_MORNING_MOISTURIZER_PRODUCT_FREQUENCY = (
  morning_moisturizer_product_frequency
) => {
  return {
    type: MORNING_MOISTURIZER_PRODUCT_FREQUENCY,
    morning_moisturizer_product_frequency,
  };
};

export default ACTION_MORNING_MOISTURIZER_PRODUCT_FREQUENCY;
