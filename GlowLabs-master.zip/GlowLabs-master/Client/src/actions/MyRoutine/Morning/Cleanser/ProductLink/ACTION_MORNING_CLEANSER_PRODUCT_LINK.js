const MORNING_CLEANSER_PRODUCT_LINK = "MORNING_CLEANSER_PRODUCT_LINK";

const ACTION_MORNING_CLEANSER_PRODUCT_LINK = (
  morning_cleanser_product_link
) => {
  return {
    type: MORNING_CLEANSER_PRODUCT_LINK,
    morning_cleanser_product_link,
  };
};

export default ACTION_MORNING_CLEANSER_PRODUCT_LINK;
