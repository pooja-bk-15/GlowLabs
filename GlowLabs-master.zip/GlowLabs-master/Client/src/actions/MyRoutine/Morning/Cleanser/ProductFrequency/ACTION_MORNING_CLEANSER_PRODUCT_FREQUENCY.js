const MORNING_CLEANSER_PRODUCT_FREQUENCY = "MORNING_CLEANSER_PRODUCT_FREQUENCY";

const ACTION_MORNING_CLEANSER_PRODUCT_FREQUENCY = (
  morning_cleanser_product_frequency
) => {
  return {
    type: MORNING_CLEANSER_PRODUCT_FREQUENCY,
    morning_cleanser_product_frequency,
  };
};

export default ACTION_MORNING_CLEANSER_PRODUCT_FREQUENCY;
