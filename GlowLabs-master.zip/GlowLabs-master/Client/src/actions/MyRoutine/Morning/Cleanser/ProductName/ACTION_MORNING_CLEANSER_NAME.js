const MORNING_CLEANSER_PRODUCT_NAME = "MORNING_CLEANSER_PRODUCT_NAME";

const ACTION_MORNING_CLEANSER_PRODUCT_NAME = (
  morning_cleanser_product_name
) => {
  return {
    type: MORNING_CLEANSER_PRODUCT_NAME,
    morning_cleanser_product_name,
  };
};

export default ACTION_MORNING_CLEANSER_PRODUCT_NAME;
