const MORNING_CLEANSER_PRODUCT_USE_NOTES = "MORNING_CLEANSER_PRODUCT_USE_NOTES";

const ACTION_MORNING_CLEANSER_PRODUCT_USE_NOTES = (
  morning_cleanser_product_use_notes
) => {
  return {
    type: MORNING_CLEANSER_PRODUCT_USE_NOTES,
    morning_cleanser_product_use_notes,
  };
};

export default ACTION_MORNING_CLEANSER_PRODUCT_USE_NOTES;
