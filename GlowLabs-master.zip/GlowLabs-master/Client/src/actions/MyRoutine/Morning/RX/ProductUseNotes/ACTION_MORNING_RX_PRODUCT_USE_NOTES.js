const MORNING_RX_PRODUCT_USE_NOTES = "MORNING_RX_PRODUCT_USE_NOTES";

const ACTION_MORNING_RX_PRODUCT_USE_NOTES = (morning_rx_product_use_notes) => {
  return {
    type: MORNING_RX_PRODUCT_USE_NOTES,
    morning_rx_product_use_notes,
  };
};

export default ACTION_MORNING_RX_PRODUCT_USE_NOTES;
