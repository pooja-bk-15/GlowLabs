const MORNING_RX_PRODUCT_NAME = "MORNING_RX_PRODUCT_NAME";

const ACTION_MORNING_RX_PRODUCT_NAME = (morning_rx_product_name) => {
  return {
    type: MORNING_RX_PRODUCT_NAME,
    morning_rx_product_name,
  };
};

export default ACTION_MORNING_RX_PRODUCT_NAME;
