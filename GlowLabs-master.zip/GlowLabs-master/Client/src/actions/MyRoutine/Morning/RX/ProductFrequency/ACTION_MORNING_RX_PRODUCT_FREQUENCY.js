const MORNING_RX_PRODUCT_FREQUENCY = "MORNING_RX_PRODUCT_FREQUENCY";

const ACTION_MORNING_RX_PRODUCT_FREQUENCY = (morning_rx_product_frequency) => {
  return {
    type: MORNING_RX_PRODUCT_FREQUENCY,
    morning_rx_product_frequency,
  };
};

export default ACTION_MORNING_RX_PRODUCT_FREQUENCY;
