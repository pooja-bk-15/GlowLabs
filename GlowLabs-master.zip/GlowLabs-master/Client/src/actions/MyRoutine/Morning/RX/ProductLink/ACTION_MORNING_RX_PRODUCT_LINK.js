const MORNING_RX_PRODUCT_LINK = "MORNING_RX_PRODUCT_LINK";

const ACTION_MORNING_RX_PRODUCT_LINK = (morning_rx_product_link) => {
  return {
    type: MORNING_RX_PRODUCT_LINK,
    morning_rx_product_link,
  };
};

export default ACTION_MORNING_RX_PRODUCT_LINK;
