const MORNING_SERUM_PRODUCT_LINK = "MORNING_SERUM_PRODUCT_LINK";

const ACTION_MORNING_SERUM_PRODUCT_LINK = (morning_serum_product_link) => {
  return {
    type: MORNING_SERUM_PRODUCT_LINK,
    morning_serum_product_link,
  };
};

export default ACTION_MORNING_SERUM_PRODUCT_LINK;
