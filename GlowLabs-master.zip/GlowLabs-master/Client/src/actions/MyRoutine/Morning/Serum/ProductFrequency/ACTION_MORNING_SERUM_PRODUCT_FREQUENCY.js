const MORNING_SERUM_PRODUCT_FREQUENCY = "MORNING_SERUM_PRODUCT_FREQUENCY";

const ACTION_MORNING_SERUM_PRODUCT_FREQUENCY = (
  morning_serum_product_frequency
) => {
  return {
    type: MORNING_SERUM_PRODUCT_FREQUENCY,
    morning_serum_product_frequency,
  };
};

export default ACTION_MORNING_SERUM_PRODUCT_FREQUENCY;
