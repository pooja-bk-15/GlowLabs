const MORNING_SERUM_PRODUCT_NAME = "MORNING_SERUM_PRODUCT_NAME";

const ACTION_MORNING_SERUM_PRODUCT_NAME = (morning_serum_product_name) => {
  return {
    type: MORNING_SERUM_PRODUCT_NAME,
    morning_serum_product_name,
  };
};

export default ACTION_MORNING_SERUM_PRODUCT_NAME;
