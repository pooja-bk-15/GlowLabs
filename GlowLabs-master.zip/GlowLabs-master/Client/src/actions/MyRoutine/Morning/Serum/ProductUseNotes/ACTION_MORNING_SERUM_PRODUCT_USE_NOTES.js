const MORNING_SERUM_PRODUCT_USE_NOTES = "MORNING_SERUM_PRODUCT_USE_NOTES";

const ACTION_MORNING_SERUM_PRODUCT_USE_NOTES = (
  morning_serum_product_use_notes
) => {
  return {
    type: MORNING_SERUM_PRODUCT_USE_NOTES,
    morning_serum_product_use_notes,
  };
};

export default ACTION_MORNING_SERUM_PRODUCT_USE_NOTES;
