const CONSENT_FORM_PAGE_2 = "CONSENT_FORM_PAGE_2";

const ACTION_CONSENT_FORM_PAGE_2 = () => {
  return {
    type: CONSENT_FORM_PAGE_2,
  };
};

export default ACTION_CONSENT_FORM_PAGE_2;
