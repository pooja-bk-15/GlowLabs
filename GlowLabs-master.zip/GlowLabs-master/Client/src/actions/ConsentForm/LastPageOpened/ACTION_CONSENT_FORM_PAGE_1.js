const CONSENT_FORM_PAGE_1 = "CONSENT_FORM_PAGE_1";

const ACTION_CONSENT_FORM_PAGE_1 = () => {
  return {
    type: CONSENT_FORM_PAGE_1,
  };
};

export default ACTION_CONSENT_FORM_PAGE_1;
