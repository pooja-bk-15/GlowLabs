const CONSENT_FORM_PAGE_6 = "CONSENT_FORM_PAGE_6";

const ACTION_CONSENT_FORM_PAGE_6 = () => {
  return {
    type: CONSENT_FORM_PAGE_6,
  };
};

export default ACTION_CONSENT_FORM_PAGE_6;
