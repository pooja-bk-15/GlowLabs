const CONSENT_FORM_PAGE_3 = "CONSENT_FORM_PAGE_3";

const ACTION_CONSENT_FORM_PAGE_3 = () => {
  return {
    type: CONSENT_FORM_PAGE_3,
  };
};

export default ACTION_CONSENT_FORM_PAGE_3;
