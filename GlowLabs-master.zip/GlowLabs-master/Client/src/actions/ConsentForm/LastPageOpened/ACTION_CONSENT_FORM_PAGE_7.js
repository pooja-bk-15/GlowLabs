const CONSENT_FORM_PAGE_7 = "CONSENT_FORM_PAGE_7";

const ACTION_CONSENT_FORM_PAGE_7 = () => {
  return {
    type: CONSENT_FORM_PAGE_7,
  };
};

export default ACTION_CONSENT_FORM_PAGE_7;
