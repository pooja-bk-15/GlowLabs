const CONSENT_FORM_PAGE_4 = "CONSENT_FORM_PAGE_4";

const ACTION_CONSENT_FORM_PAGE_4 = () => {
  return {
    type: CONSENT_FORM_PAGE_4,
  };
};

export default ACTION_CONSENT_FORM_PAGE_4;
