const CONSENT_FORM_PAGE_5 = "CONSENT_FORM_PAGE_5";

const ACTION_CONSENT_FORM_PAGE_5 = () => {
  return {
    type: CONSENT_FORM_PAGE_5,
  };
};

export default ACTION_CONSENT_FORM_PAGE_5;
