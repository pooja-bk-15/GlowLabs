const ANY_HEALTH_PROBLEMS_NOTES = "ANY_HEALTH_PROBLEMS_NOTES";

const ACTION_ANY_HEALTH_PROBLEMS_NOTES = any_health_problems_notes => {
  return {
    type: ANY_HEALTH_PROBLEMS_NOTES,
    any_health_problems_notes
  };
};

export default ACTION_ANY_HEALTH_PROBLEMS_NOTES;
