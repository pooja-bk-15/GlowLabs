const GLYCOLIC_ACID = "GLYCOLIC_ACID";

const ACTION_GLYCOLIC_ACID = () => {
  return {
    type: GLYCOLIC_ACID
  };
};

export default ACTION_GLYCOLIC_ACID;
