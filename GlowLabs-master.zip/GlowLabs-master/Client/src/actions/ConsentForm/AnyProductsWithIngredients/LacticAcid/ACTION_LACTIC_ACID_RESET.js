const LACTIC_ACID_RESET = "LACTIC_ACID_RESET";

const ACTION_LACTIC_ACID_RESET = () => {
  return {
    type: LACTIC_ACID_RESET
  };
};

export default ACTION_LACTIC_ACID_RESET;
