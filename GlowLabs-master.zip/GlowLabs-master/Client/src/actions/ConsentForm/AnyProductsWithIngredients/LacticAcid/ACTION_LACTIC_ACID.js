const LACTIC_ACID = "LACTIC_ACID";

const ACTION_LACTIC_ACID = () => {
  return {
    type: LACTIC_ACID
  };
};

export default ACTION_LACTIC_ACID;
