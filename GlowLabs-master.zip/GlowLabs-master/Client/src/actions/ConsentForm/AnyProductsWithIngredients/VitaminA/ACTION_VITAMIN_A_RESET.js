const VITAMIN_A_RESET = "VITAMIN_A_RESET";

const ACTION_VITAMIN_A_RESET = () => {
  return {
    type: VITAMIN_A_RESET
  };
};

export default ACTION_VITAMIN_A_RESET;
