const VITAMIN_A = "VITAMIN_A";

const ACTION_VITAMIN_A = () => {
  return {
    type: VITAMIN_A
  };
};

export default ACTION_VITAMIN_A;
