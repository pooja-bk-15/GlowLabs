const SALICYCLIC_ACID = "SALICYCLIC_ACID";

const ACTION_SALICYCLIC_ACID = () => {
  return {
    type: SALICYCLIC_ACID
  };
};

export default ACTION_SALICYCLIC_ACID;
