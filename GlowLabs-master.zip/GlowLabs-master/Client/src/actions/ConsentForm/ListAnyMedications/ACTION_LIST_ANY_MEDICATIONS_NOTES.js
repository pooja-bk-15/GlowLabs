const LIST_ANY_MEDICATIONS_NOTES = "LIST_ANY_MEDICATIONS_NOTES";

const ACTION_LIST_ANY_MEDICATIONS_NOTES = list_any_medications_notes => {
  return {
    type: LIST_ANY_MEDICATIONS_NOTES,
    list_any_medications_notes
  };
};

export default ACTION_LIST_ANY_MEDICATIONS_NOTES;
