const SURGERY_LAST_3_MONTHS_NOTES = "SURGERY_LAST_3_MONTHS_NOTES";

const ACTION_SURGERY_LAST_3_MONTHS_NOTES = surgery_last_3_months_notes => {
  return {
    type: SURGERY_LAST_3_MONTHS_NOTES,
    surgery_last_3_months_notes
  };
};

export default ACTION_SURGERY_LAST_3_MONTHS_NOTES;
