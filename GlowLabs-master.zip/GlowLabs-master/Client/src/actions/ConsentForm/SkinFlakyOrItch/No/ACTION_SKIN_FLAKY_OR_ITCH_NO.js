const SKIN_FLAKY_OR_ITCH_NO = "SKIN_FLAKY_OR_ITCH_NO";

const ACTION_SKIN_FLAKY_OR_ITCH_NO = () => {
  return {
    type: SKIN_FLAKY_OR_ITCH_NO,
  };
};

export default ACTION_SKIN_FLAKY_OR_ITCH_NO;
