const SKIN_FLAKY_OR_ITCH_YES = "SKIN_FLAKY_OR_ITCH_YES";

const ACTION_SKIN_FLAKY_OR_ITCH_YES = () => {
  return {
    type: SKIN_FLAKY_OR_ITCH_YES,
  };
};

export default ACTION_SKIN_FLAKY_OR_ITCH_YES;
