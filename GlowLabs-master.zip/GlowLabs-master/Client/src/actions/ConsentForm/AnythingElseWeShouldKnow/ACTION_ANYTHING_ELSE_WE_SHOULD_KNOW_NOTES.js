const ANYTHING_ELSE_WE_SHOULD_KNOW_NOTES = "ANYTHING_ELSE_WE_SHOULD_KNOW_NOTES";

const ACTION_ANYTHING_ELSE_WE_SHOULD_KNOW_NOTES = (
  anything_else_we_should_know_notes
) => {
  return {
    type: ANYTHING_ELSE_WE_SHOULD_KNOW_NOTES,
    anything_else_we_should_know_notes,
  };
};

export default ACTION_ANYTHING_ELSE_WE_SHOULD_KNOW_NOTES;
