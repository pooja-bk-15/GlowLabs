const ANY_FILLERS_OR_BOTOX_NOTES = "ANY_FILLERS_OR_BOTOX_NOTES";

const ACTION_ANY_FILLERS_OR_BOTOX_NOTES = any_fillers_or_botox_notes => {
  return {
    type: ANY_FILLERS_OR_BOTOX_NOTES,
    any_fillers_or_botox_notes
  };
};

export default ACTION_ANY_FILLERS_OR_BOTOX_NOTES;
