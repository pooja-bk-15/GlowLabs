const ANY_ACCUTANE_NO = "ANY_ACCUTANE_NO";

const ACTION_ANY_ACCUTANE_NO = () => {
  return {
    type: ANY_ACCUTANE_NO
  };
};

export default ACTION_ANY_ACCUTANE_NO;
