const ANY_ACCUTANE_YES = "ANY_ACCUTANE_YES";

const ACTION_ANY_ACCUTANE_YES = () => {
  return {
    type: ANY_ACCUTANE_YES
  };
};

export default ACTION_ANY_ACCUTANE_YES;
