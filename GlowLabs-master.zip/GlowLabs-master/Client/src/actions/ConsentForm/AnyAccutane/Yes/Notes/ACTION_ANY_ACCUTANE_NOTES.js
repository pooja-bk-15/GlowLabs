const ANY_ACCUTANE_NOTES = "ANY_ACCUTANE_NOTES";

const ACTION_ANY_ACCUTANE_NOTES = any_accutane_notes => {
  return {
    type: ANY_ACCUTANE_NOTES,
    any_accutane_notes
  };
};

export default ACTION_ANY_ACCUTANE_NOTES;
