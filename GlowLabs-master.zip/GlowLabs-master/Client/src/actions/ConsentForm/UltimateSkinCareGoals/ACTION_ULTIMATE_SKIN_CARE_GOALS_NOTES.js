const ULTIMATE_SKIN_CARE_GOALS_NOTES = "ULTIMATE_SKIN_CARE_GOALS_NOTES";

const ACTION_ULTIMATE_SKIN_CARE_GOALS_NOTES = (
  ultimate_skin_care_goals_notes
) => {
  return {
    type: ULTIMATE_SKIN_CARE_GOALS_NOTES,
    ultimate_skin_care_goals_notes,
  };
};

export default ACTION_ULTIMATE_SKIN_CARE_GOALS_NOTES;
