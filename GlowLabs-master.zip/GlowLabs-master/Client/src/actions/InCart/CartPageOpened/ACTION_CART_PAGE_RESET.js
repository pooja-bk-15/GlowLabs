const CART_PAGE_RESET = "CART_PAGE_RESET";

const ACTION_CART_PAGE_RESET = () => {
  return {
    type: CART_PAGE_RESET,
  };
};

export default ACTION_CART_PAGE_RESET;
