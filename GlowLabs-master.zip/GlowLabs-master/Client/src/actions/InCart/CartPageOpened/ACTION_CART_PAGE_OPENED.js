const CART_PAGE_OPENED = "CART_PAGE_OPENED";

const ACTION_CART_PAGE_OPENED = () => {
  return {
    type: CART_PAGE_OPENED,
  };
};

export default ACTION_CART_PAGE_OPENED;
