const HYDROJELLY_NOT_IN_CART = "HYDROJELLY_NOT_IN_CART";

const ACTION_HYDROJELLY_NOT_IN_CART = () => {
  return {
    type: HYDROJELLY_NOT_IN_CART,
    payload: {
      name: "HydroJelly"
    }
  };
};

export default ACTION_HYDROJELLY_NOT_IN_CART;
