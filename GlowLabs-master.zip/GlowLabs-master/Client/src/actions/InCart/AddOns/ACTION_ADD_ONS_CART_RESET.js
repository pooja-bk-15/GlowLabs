const ADD_ONS_CART_RESET = "ADD_ONS_CART_RESET";

const ACTION_ADD_ONS_CART_RESET = () => {
  return {
    type: ADD_ONS_CART_RESET
  };
};

export default ACTION_ADD_ONS_CART_RESET;
