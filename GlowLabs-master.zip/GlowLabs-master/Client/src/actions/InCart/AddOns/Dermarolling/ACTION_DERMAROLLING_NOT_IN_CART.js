const DERMAROLLING_NOT_IN_CART = "DERMAROLLING_NOT_IN_CART";

const ACTION_DERMAROLLING_NOT_IN_CART = () => {
  return {
    type: DERMAROLLING_NOT_IN_CART,
    payload: {
      name: "Dermarolling"
    }
  };
};

export default ACTION_DERMAROLLING_NOT_IN_CART;
