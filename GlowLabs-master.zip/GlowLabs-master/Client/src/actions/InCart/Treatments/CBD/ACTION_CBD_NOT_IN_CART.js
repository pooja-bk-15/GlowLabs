const CBD_NOT_IN_CART = "CBD_NOT_IN_CART";

const ACTION_CBD_NOT_IN_CART = () => {
  return {
    type: CBD_NOT_IN_CART,
    payload: {
      name: "CBD"
    }
  };
};

export default ACTION_CBD_NOT_IN_CART;
