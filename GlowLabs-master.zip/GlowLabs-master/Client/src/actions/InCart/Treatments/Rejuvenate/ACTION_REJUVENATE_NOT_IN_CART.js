const REJUVENATE_NOT_IN_CART = "REJUVENATE_NOT_IN_CART";

const ACTION_REJUVENATE_NOT_IN_CART = () => {
  return {
    type: REJUVENATE_NOT_IN_CART,
    payload: {
      name: "Rejuvenate"
    }
  };
};

export default ACTION_REJUVENATE_NOT_IN_CART;
