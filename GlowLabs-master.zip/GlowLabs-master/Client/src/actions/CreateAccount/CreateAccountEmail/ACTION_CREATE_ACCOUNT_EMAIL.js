const CREATE_ACCOUNT_EMAIL = "CREATE_ACCOUNT_EMAIL";

const ACTION_CREATE_ACCOUNT_EMAIL = create_account_email => {
  return {
    type: CREATE_ACCOUNT_EMAIL,
    create_account_email
  };
};

export default ACTION_CREATE_ACCOUNT_EMAIL;
