const CREATE_ACCOUNT_PHONE_NUMBER = "CREATE_ACCOUNT_PHONE_NUMBER";

const ACTION_CREATE_ACCOUNT_PHONE_NUMBER = create_account_phone_number => {
  return {
    type: CREATE_ACCOUNT_PHONE_NUMBER,
    create_account_phone_number
  };
};

export default ACTION_CREATE_ACCOUNT_PHONE_NUMBER;
