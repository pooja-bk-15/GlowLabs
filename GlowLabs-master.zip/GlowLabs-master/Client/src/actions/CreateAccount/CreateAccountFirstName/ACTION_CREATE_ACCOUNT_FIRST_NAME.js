const CREATE_ACCOUNT_FIRST_NAME = "CREATE_ACCOUNT_FIRST_NAME";

const ACTION_CREATE_ACCOUNT_FIRST_NAME = create_account_first_name => {
  return {
    type: CREATE_ACCOUNT_FIRST_NAME,
    create_account_first_name
  };
};

export default ACTION_CREATE_ACCOUNT_FIRST_NAME;
