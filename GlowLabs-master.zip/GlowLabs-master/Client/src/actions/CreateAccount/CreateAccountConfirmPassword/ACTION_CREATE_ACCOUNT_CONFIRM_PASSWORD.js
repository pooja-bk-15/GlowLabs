const CREATE_ACCOUNT_CONFIRM_PASSWORD = "CREATE_ACCOUNT_CONFIRM_PASSWORD";

const ACTION_CREATE_ACCOUNT_CONFIRM_PASSWORD = create_account_confirm_password => {
  return {
    type: CREATE_ACCOUNT_CONFIRM_PASSWORD,
    create_account_confirm_password
  };
};

export default ACTION_CREATE_ACCOUNT_CONFIRM_PASSWORD;
