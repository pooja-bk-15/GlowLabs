const CREATE_ACCOUNT_LAST_NAME = "CREATE_ACCOUNT_LAST_NAME";

const ACTION_CREATE_ACCOUNT_LAST_NAME = create_account_last_name => {
  return {
    type: CREATE_ACCOUNT_LAST_NAME,
    create_account_last_name
  };
};

export default ACTION_CREATE_ACCOUNT_LAST_NAME;
