const PDF_LOADING_RESET = "PDF_LOADING_RESET";

const ACTION_PDF_LOADING_RESET = () => {
  return {
    type: PDF_LOADING_RESET,
  };
};

export default ACTION_PDF_LOADING_RESET;
