const PDF_LOADING = "PDF_LOADING";

const ACTION_PDF_LOADING = () => {
  return {
    type: PDF_LOADING,
  };
};

export default ACTION_PDF_LOADING;
