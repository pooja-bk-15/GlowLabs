const TOTAL_PRICE_RESET = "TOTAL_PRICE_RESET";

const ACTION_TOTAL_PRICE_RESET = () => {
  return {
    type: TOTAL_PRICE_RESET
  };
};

export default ACTION_TOTAL_PRICE_RESET;
