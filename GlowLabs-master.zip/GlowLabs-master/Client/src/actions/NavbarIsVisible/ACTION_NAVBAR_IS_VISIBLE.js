const NAVBAR_IS_VISIBLE = "NAVBAR_IS_VISIBLE";

const ACTION_NAVBAR_IS_VISIBLE = () => {
  return {
    type: NAVBAR_IS_VISIBLE
  };
};

export default ACTION_NAVBAR_IS_VISIBLE;
