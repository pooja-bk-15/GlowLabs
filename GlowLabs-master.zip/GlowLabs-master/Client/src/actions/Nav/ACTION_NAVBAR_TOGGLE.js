const NAVBAR_TOGGLE = "NAVBAR_TOGGLE";

const ACTION_NAVBAR_TOGGLE = () => {
  return {
    type: NAVBAR_TOGGLE
  };
};

export default ACTION_NAVBAR_TOGGLE;
