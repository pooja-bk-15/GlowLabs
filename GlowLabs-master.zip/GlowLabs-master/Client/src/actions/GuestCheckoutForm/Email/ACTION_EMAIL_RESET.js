const EMAIL_RESET = "EMAIL_RESET";

const ACTION_EMAIL_RESET = () => {
  return {
    type: EMAIL_RESET
  };
};

export default ACTION_EMAIL_RESET;
