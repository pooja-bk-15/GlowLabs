const LAST_NAME_RESET = "LAST_NAME_RESET";

const ACTION_LAST_NAME_RESET = () => {
  return {
    type: LAST_NAME_RESET
  };
};

export default ACTION_LAST_NAME_RESET;
