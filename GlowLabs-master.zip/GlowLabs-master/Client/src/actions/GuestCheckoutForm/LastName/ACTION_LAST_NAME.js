const LAST_NAME = "LAST_NAME";

const ACTION_LAST_NAME = last_name => {
  return {
    type: LAST_NAME,
    last_name
  };
};

export default ACTION_LAST_NAME;
