const FIRST_NAME = "FIRST_NAME";

const ACTION_FIRST_NAME = first_name => {
  return {
    type: FIRST_NAME,
    first_name
  };
};

export default ACTION_FIRST_NAME;
