const FIRST_NAME_RESET = "FIRST_NAME_RESET";

const ACTION_FIRST_NAME_RESET = () => {
  return {
    type: FIRST_NAME_RESET
  };
};

export default ACTION_FIRST_NAME_RESET;
