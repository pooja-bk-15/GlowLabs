const PHONE_NOT_VALID = "PHONE_NOT_VALID";

const ACTION_PHONE_NOT_VALID = () => {
  return {
    type: PHONE_NOT_VALID
  };
};

export default ACTION_PHONE_NOT_VALID;
