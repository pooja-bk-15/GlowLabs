const PHONE_VALID = "PHONE_VALID";

const ACTION_PHONE_VALID = () => {
  return {
    type: PHONE_VALID
  };
};

export default ACTION_PHONE_VALID;
