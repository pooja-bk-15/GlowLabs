const PHONE_NOT_INVALID = "PHONE_NOT_INVALID";

const ACTION_PHONE_NOT_INVALID = () => {
  return {
    type: PHONE_NOT_INVALID
  };
};

export default ACTION_PHONE_NOT_INVALID;
