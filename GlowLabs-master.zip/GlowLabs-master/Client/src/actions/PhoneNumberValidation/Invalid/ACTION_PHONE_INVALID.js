const PHONE_INVALID = "PHONE_INVALID";

const ACTION_PHONE_INVALID = () => {
  return {
    type: PHONE_INVALID
  };
};

export default ACTION_PHONE_INVALID;
