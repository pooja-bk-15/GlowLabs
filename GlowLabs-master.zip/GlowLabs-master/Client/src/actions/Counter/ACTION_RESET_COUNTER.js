const RESET_COUNTER = "RESET_COUNTER";

const ACTION_RESET_COUNTER = () => {
  return {
    type: RESET_COUNTER
  };
};

export default ACTION_RESET_COUNTER;
