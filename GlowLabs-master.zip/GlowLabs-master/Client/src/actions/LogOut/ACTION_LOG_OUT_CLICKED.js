const LOG_OUT_CLICKED = "LOG_OUT_CLICKED";

const ACTION_LOG_OUT_CLICKED = () => {
  return {
    type: LOG_OUT_CLICKED,
  };
};

export default ACTION_LOG_OUT_CLICKED;
