const SAVE_CARD_CHECKED = "SAVE_CARD_CHECKED";

const ACTION_SAVE_CARD_CHECKED = () => {
  return {
    type: SAVE_CARD_CHECKED,
  };
};

export default ACTION_SAVE_CARD_CHECKED;
