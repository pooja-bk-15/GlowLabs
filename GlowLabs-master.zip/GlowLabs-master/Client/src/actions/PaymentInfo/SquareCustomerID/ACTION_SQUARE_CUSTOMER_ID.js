const SQUARE_CUSTOMER_ID = "SQUARE_CUSTOMER_ID";

const ACTION_SQUARE_CUSTOMER_ID = (square_customer_id) => {
  return {
    type: SQUARE_CUSTOMER_ID,
    square_customer_id,
  };
};

export default ACTION_SQUARE_CUSTOMER_ID;
