const ON_ACTIVITY_PAGE = "ON_ACTIVITY_PAGE";

const ACTION_ON_ACTIVITY_PAGE = () => {
  return {
    type: ON_ACTIVITY_PAGE,
  };
};

export default ACTION_ON_ACTIVITY_PAGE;
