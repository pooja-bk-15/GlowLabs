const ADMIN_STAFF_MEMBER_PHONE_NUMBER = "ADMIN_STAFF_MEMBER_PHONE_NUMBER";

const ACTION_ADMIN_STAFF_MEMBER_PHONE_NUMBER = (
  admin_staff_member_phone_number
) => {
  return {
    type: ADMIN_STAFF_MEMBER_PHONE_NUMBER,
    admin_staff_member_phone_number,
  };
};

export default ACTION_ADMIN_STAFF_MEMBER_PHONE_NUMBER;
