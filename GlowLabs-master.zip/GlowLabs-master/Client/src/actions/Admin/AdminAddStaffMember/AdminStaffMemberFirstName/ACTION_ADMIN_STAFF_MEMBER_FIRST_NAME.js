const ADMIN_STAFF_MEMBER_FIRST_NAME = "ADMIN_STAFF_MEMBER_FIRST_NAME";

const ACTION_ADMIN_STAFF_MEMBER_FIRST_NAME = (
  admin_staff_member_first_name
) => {
  return {
    type: ADMIN_STAFF_MEMBER_FIRST_NAME,
    admin_staff_member_first_name,
  };
};

export default ACTION_ADMIN_STAFF_MEMBER_FIRST_NAME;
