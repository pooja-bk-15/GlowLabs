const ADMIN_STAFF_MEMBER_LAST_NAME = "ADMIN_STAFF_MEMBER_LAST_NAME";

const ACTION_ADMIN_STAFF_MEMBER_LAST_NAME = (admin_staff_member_last_name) => {
  return {
    type: ADMIN_STAFF_MEMBER_LAST_NAME,
    admin_staff_member_last_name,
  };
};

export default ACTION_ADMIN_STAFF_MEMBER_LAST_NAME;
