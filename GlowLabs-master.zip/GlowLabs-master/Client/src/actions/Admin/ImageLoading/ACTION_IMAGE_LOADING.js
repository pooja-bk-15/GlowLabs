const IMAGE_LOADING = "IMAGE_LOADING";

const ACTION_IMAGE_LOADING = () => {
  return {
    type: IMAGE_LOADING,
  };
};

export default ACTION_IMAGE_LOADING;
