const MORNING_CLOSED = "MORNING_CLOSED";

const ACTION_MORNING_CLOSED = () => {
  return {
    type: MORNING_CLOSED
  };
};

export default ACTION_MORNING_CLOSED;
