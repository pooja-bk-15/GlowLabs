const MORNING_OPEN = "MORNING_OPEN";

const ACTION_MORNING_OPEN = () => {
  return {
    type: MORNING_OPEN
  };
};

export default ACTION_MORNING_OPEN;
