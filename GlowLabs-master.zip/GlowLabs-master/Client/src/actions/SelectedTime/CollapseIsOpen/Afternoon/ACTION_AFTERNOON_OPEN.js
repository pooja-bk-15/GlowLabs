const AFTERNOON_OPEN = "AFTERNOON_OPEN";

const ACTION_AFTERNOON_OPEN = () => {
  return {
    type: AFTERNOON_OPEN
  };
};

export default ACTION_AFTERNOON_OPEN;
