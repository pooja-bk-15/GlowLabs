const EVENING_CLOSED = "EVENING_CLOSED";

const ACTION_EVENING_CLOSED = () => {
  return {
    type: EVENING_CLOSED
  };
};

export default ACTION_EVENING_CLOSED;
