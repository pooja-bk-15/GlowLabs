const EVENING_OPEN = "EVENING_OPEN";

const ACTION_EVENING_OPEN = () => {
  return {
    type: EVENING_OPEN
  };
};

export default ACTION_EVENING_OPEN;
