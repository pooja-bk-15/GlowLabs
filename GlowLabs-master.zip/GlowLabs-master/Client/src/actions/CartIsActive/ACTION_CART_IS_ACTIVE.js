const CART_IS_ACTIVE = "CART_IS_ACTIVE";

const ACTION_CART_IS_ACTIVE = () => {
  return {
    type: CART_IS_ACTIVE
  };
};

export default ACTION_CART_IS_ACTIVE;
