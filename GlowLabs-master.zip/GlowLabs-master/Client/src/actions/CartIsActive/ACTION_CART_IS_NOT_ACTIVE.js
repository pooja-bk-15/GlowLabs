const CART_IS_NOT_ACTIVE = "CART_IS_NOT_ACTIVE";

const ACTION_CART_IS_NOT_ACTIVE = () => {
  return {
    type: CART_IS_NOT_ACTIVE
  };
};

export default ACTION_CART_IS_NOT_ACTIVE;
