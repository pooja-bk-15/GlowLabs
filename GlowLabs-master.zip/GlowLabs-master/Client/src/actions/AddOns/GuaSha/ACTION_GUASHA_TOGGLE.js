const GUASHA_TOGGLE = "GUASHA_TOGGLE";

const ACTION_GUASHA_TOGGLE = () => {
  return {
    type: GUASHA_TOGGLE
  };
};

export default ACTION_GUASHA_TOGGLE;
