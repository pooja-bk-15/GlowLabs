const BEARD_TOGGLE = "BEARD_TOGGLE";

const ACTION_BEARD_TOGGLE = () => {
  return {
    type: BEARD_TOGGLE
  };
};

export default ACTION_BEARD_TOGGLE;
