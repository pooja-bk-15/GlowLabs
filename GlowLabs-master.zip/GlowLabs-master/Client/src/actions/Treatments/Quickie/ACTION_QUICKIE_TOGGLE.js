const QUICKIE_TOGGLE = "QUICKIE_TOGGLE";

const ACTION_QUICKIE_TOGGLE = () => {
  return {
    type: QUICKIE_TOGGLE
  };
};

export default ACTION_QUICKIE_TOGGLE;
