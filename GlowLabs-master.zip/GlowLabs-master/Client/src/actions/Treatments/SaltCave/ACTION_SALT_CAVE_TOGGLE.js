const SALT_CAVE_TOGGLE = "SALT_CAVE_TOGGLE";

const ACTION_SALT_CAVE_TOGGLE = () => {
  return {
    type: SALT_CAVE_TOGGLE,
  };
};

export default ACTION_SALT_CAVE_TOGGLE;
