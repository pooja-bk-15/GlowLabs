const BACIAL_TOGGLE = "BACIAL_TOGGLE";

const ACTION_BACIAL_TOGGLE = () => {
  return {
    type: BACIAL_TOGGLE
  };
};

export default ACTION_BACIAL_TOGGLE;
