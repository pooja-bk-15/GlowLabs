const CALM_TOGGLE_RESET = "CALM_TOGGLE_RESET";

const ACTION_CALM_TOGGLE_RESET = () => {
  return {
    type: CALM_TOGGLE_RESET
  };
};

export default ACTION_CALM_TOGGLE_RESET;
