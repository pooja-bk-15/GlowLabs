const CALM_TOGGLE = "CALM_TOGGLE";

const ACTION_CALM_TOGGLE = () => {
  return {
    type: CALM_TOGGLE
  };
};

export default ACTION_CALM_TOGGLE;
