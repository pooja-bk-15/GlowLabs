const CBD_TOGGLE = "CBD_TOGGLE";

const ACTION_CBD_TOGGLE = () => {
  return {
    type: CBD_TOGGLE
  };
};

export default ACTION_CBD_TOGGLE;
