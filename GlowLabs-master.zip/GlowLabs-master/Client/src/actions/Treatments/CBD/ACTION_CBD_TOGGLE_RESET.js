const CBD_TOGGLE_RESET = "CBD_TOGGLE_RESET";

const ACTION_CBD_TOGGLE_RESET = () => {
  return {
    type: CBD_TOGGLE_RESET
  };
};

export default ACTION_CBD_TOGGLE_RESET;
