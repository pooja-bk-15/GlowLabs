const GLOW_TOGGLE_RESET = "GLOW_TOGGLE_RESET";

const ACTION_GLOW_TOGGLE_RESET = () => {
  return {
    type: GLOW_TOGGLE_RESET
  };
};

export default ACTION_GLOW_TOGGLE_RESET;
