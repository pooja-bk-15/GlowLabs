const GLOW_TOGGLE = "GLOW_TOGGLE";

const ACTION_GLOW_TOGGLE = () => {
  return {
    type: GLOW_TOGGLE
  };
};

export default ACTION_GLOW_TOGGLE;
