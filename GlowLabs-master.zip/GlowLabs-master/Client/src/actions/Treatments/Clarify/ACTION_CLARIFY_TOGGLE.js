const CLARIFY_TOGGLE = "CLARIFY_TOGGLE";

const ACTION_CLARIFY_TOGGLE = () => {
  return {
    type: CLARIFY_TOGGLE
  };
};

export default ACTION_CLARIFY_TOGGLE;
