const QUENCH_TOGGLE = "QUENCH_TOGGLE";

const ACTION_QUENCH_TOGGLE = () => {
  return {
    type: QUENCH_TOGGLE
  };
};

export default ACTION_QUENCH_TOGGLE;
